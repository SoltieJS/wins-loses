function newWin() {
    const options = {
        method:"POST",
    }

    fetch("http://192.168.0.174:3000/api/new/win", options).then(res=>{
        console.log(res)
        alert("Win adicionada com sucesso!");
    })
}

function newLose() {
    const options = {
        method:"POST",
    }

    fetch("http://192.168.0.174:3000/api/new/lose", options).then(res=>{
        console.log(res)
        alert("Lose adicionada com sucesso!");
    })
}

function removeWin() {
    const options = {
        method:"DELETE",
    }

    fetch("http://192.168.0.174:3000/api/remove/win", options).then(res=>{
        console.log(res)
        alert("Win removida com sucesso!");
    })
}

function removeLose() {
    const options = {
        method:"DELETE",
    }

    fetch("http://192.168.0.174:3000/api/remove/lose", options).then(res=>{
        console.log(res)
        alert("Lose removida com sucesso!");
    })
}

function clearAll() {
    const options = {
        method:"DELETE",
    }

    fetch("http://192.168.0.174:3000/api/clear", options).then(res=>{
        console.log(res)
        alert("Todas wins e loses foram limpadas com sucesso!!");
    })
}

