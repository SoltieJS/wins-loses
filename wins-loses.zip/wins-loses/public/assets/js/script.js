document.addEventListener("DOMContentLoaded", () => {
    updatePosts()
})

function updatePosts() {
    fetch("http://192.168.0.174:3000/api/all").then(res => {
        return res.json();
    }).then(json => {
            let posts = JSON.parse(json);
            let winElement = `W: ${posts.wins}`;
            let losesElement = `L: ${posts.loses}`;

        document.getElementById("wins").innerHTML = winElement;
        document.getElementById("loses").innerHTML = losesElement;
    })
}

setInterval(() => {
    updatePosts()
}, 10000);