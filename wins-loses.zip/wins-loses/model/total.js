module.exports = {
    all:{
            wins: 0,
            loses: 0,
            draws: 0,
    },
    getAll() {
        return this.all
    },
    
    newWin() {
        this.all.wins++;
    },

    newLose() {
        this.all.loses++;
    },

    removeWin() {
        this.all.wins--;
    },

    removeLose() {
        this.all.loses--;
    },

    clear() {
        this.all.wins = 0;
        this.all.loses = 0;
    },
}