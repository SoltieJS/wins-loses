const express = require("express");
const bodyParser = require("body-parser");

const router = express.Router();

const posts = require('../model/total');

router.get("/all", (req, res) => {
    let all = JSON.stringify(posts.getAll());
    res.json(JSON.stringify(posts.getAll()));
    console.log(posts.getAll().wins);
})

router.post('/new/win', express.json(), (req,res)=>{
    
    posts.newWin()

    res.send("Win adicionado com sucesso.");
})

router.post('/new/lose', express.json(), (req,res)=>{
    
    posts.newLose()

    res.send("Lose adicionado com sucesso.");
})

router.delete('/remove/win', express.json(), (req,res)=>{
    posts.removeWin()

    res.send("Win removida com sucesso.");
})

router.delete('/remove/lose', express.json(), (req,res)=>{
    
    posts.removeLose()

    res.send("Lose removida com sucesso.");
})

router.delete('/clear', express.json(), (req,res)=>{
    
    posts.clear()

    res.send("Clear feito com sucesso!");
})


module.exports = router;